package com.aram.legalaid.service;

import com.aram.legalaid.model.*;
import com.aram.legalaid.repository.*;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class LegalGuideLevelService {

    @Autowired
    private LegalGuideLevelRuleRepository levelRuleRepository;

    @Autowired
    private LegalGuidePerformanceProfileRepository performanceProfileRepository;

    @Autowired
    private LegalGuideCreditTransactionRepository creditTransactionRepository;

    @Autowired
    private LegalGuideProfileRepository guideProfileRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuditLogService auditLogService;

    @Autowired
    private NotificationService notificationService;

    @PostConstruct
    public void init() {
        seedLevelRules();
    }

    private void seedLevelRules() {
        if (levelRuleRepository.count() == 0) {
            System.out.println("Seeding Legal Guide Level Rules...");
            levelRuleRepository.save(new LegalGuideLevelRule(1, "Beginner Legal Guide", 0, 99, "Beginner", 1.0));
            levelRuleRepository.save(new LegalGuideLevelRule(2, "Active Legal Guide", 100, 249, "Active", 1.1));
            levelRuleRepository.save(new LegalGuideLevelRule(3, "Trusted Legal Guide", 250, 499, "Trusted Advisor", 1.2));
            levelRuleRepository.save(new LegalGuideLevelRule(4, "Senior Legal Guide", 500, 899, "Senior Specialist", 1.3));
            levelRuleRepository.save(new LegalGuideLevelRule(5, "Expert Legal Guide", 900, 1499, "Expert Advisor", 1.4));
            levelRuleRepository.save(new LegalGuideLevelRule(6, "Lead Legal Guide", 1500, Integer.MAX_VALUE, "Lead Advocate", 1.5));
            System.out.println("Successfully seeded 6 Level Rules.");
        }
    }

    @Transactional
    public void addCredit(Long legalGuideId, Long complaintId, String transactionType, int points, String reason, Long awardedByUserId, String awardedByRole, String source) {
        // Save credit transaction
        LegalGuideCreditTransaction tx = new LegalGuideCreditTransaction(
            legalGuideId, complaintId, transactionType, points, reason, awardedByUserId, awardedByRole, source
        );
        creditTransactionRepository.save(tx);

        // Fetch performance profile
        LegalGuidePerformanceProfile perf = getOrCreatePerformanceProfile(legalGuideId);
        int oldScore = perf.getCreditScore();
        int newScore = Math.max(0, oldScore + points);
        perf.setCreditScore(newScore);

        // Track metrics based on transaction type
        if ("CASE_RESOLVED_BY_GUIDE".equals(transactionType)) {
            perf.setCasesResolved(perf.getCasesResolved() + 1);
        } else if ("USER_CONFIRMED_RESOLVED".equals(transactionType)) {
            perf.setCasesConfirmedResolved(perf.getCasesConfirmedResolved() + 1);
        } else if ("CASE_REOPENED_POOR_GUIDANCE".equals(transactionType)) {
            perf.setCasesReopened(perf.getCasesReopened() + 1);
            perf.setDowngradeReviewRequired(true);
            auditLogService.log("DOWNGRADE_REVIEW_FLAGGED", "SYSTEM", "Guide ID " + legalGuideId + " flagged due to case reopen");
        } else if ("PRIVACY_VIOLATION".equals(transactionType)) {
            perf.setPrivacyViolationCount(perf.getPrivacyViolationCount() + 1);
            perf.setDowngradeReviewRequired(true);
            auditLogService.log("DOWNGRADE_REVIEW_FLAGGED", "SYSTEM", "Guide ID " + legalGuideId + " flagged due to privacy violation");
        } else if ("ACTION_PLAN_SHARED".equals(transactionType)) {
            perf.setActionPlanSharedCount(perf.getActionPlanSharedCount() + 1);
        } else if ("DOCUMENT_REQUEST_CREATED".equals(transactionType)) {
            perf.setDocumentRequestCount(perf.getDocumentRequestCount() + 1);
        }

        performanceProfileRepository.save(perf);
        
        // Log audit trail
        String actionType = points >= 0 ? "CREDIT_AWARDED" : "CREDIT_DEDUCTED";
        auditLogService.log(actionType, awardedByRole != null ? awardedByRole : "SYSTEM", 
            "Points: " + points + " for Guide: " + legalGuideId + " reason: " + reason);

        // Evaluate level upgrade/downgrade rules
        evaluateLevel(legalGuideId, oldScore, newScore);
    }

    private void evaluateLevel(Long legalGuideId, int oldScore, int newScore) {
        LegalGuidePerformanceProfile perf = getOrCreatePerformanceProfile(legalGuideId);
        List<LegalGuideLevelRule> rules = levelRuleRepository.findAllByActiveTrueOrderByLevelNumberAsc();
        
        LegalGuideLevelRule targetRule = null;
        for (LegalGuideLevelRule rule : rules) {
            if (newScore >= rule.getMinCreditScore() && newScore <= rule.getMaxCreditScore()) {
                targetRule = rule;
                break;
            }
        }

        if (targetRule != null && targetRule.getLevelNumber() != perf.getCurrentLevelNumber()) {
            final LegalGuideLevelRule finalTargetRule = targetRule;
            int oldLevel = perf.getCurrentLevelNumber();
            int newLevel = targetRule.getLevelNumber();
            
            // Upgrades happen automatically if eligible (reopen rate is acceptable, no pending violations)
            if (newLevel > oldLevel) {
                boolean hasPrivacyViolations = perf.getPrivacyViolationCount() > 0;
                double reopenRate = perf.getCasesAssigned() > 0 ? (double) perf.getCasesReopened() / perf.getCasesAssigned() : 0.0;
                
                if (reopenRate < 0.25 && !hasPrivacyViolations) {
                    perf.setCurrentLevelNumber(newLevel);
                    perf.setCurrentLevelName(targetRule.getLevelName());
                    perf.setLastLevelUpdatedAt(LocalDateTime.now());
                    performanceProfileRepository.save(perf);

                    // Notify
                    userRepository.findById(legalGuideId).ifPresent(user -> 
                        notificationService.create(user, "Level Upgraded: Congratulations! You are now a " + finalTargetRule.getLevelName() + ".", com.aram.legalaid.enums.NotificationType.IN_APP)
                    );
                    
                    auditLogService.log("LEVEL_UPGRADED", "SYSTEM", 
                        "Guide ID " + legalGuideId + " upgraded from Level " + oldLevel + " to " + newLevel);
                }
            } else {
                // Downgrades are flagged for Admin Review first
                perf.setDowngradeReviewRequired(true);
                performanceProfileRepository.save(perf);
                auditLogService.log("DOWNGRADE_REVIEW_FLAGGED", "SYSTEM", 
                    "Guide ID " + legalGuideId + " level drop from " + oldLevel + " to " + newLevel + " requires Admin approval");
            }
        }
    }

    @Transactional
    public void approveDowngrade(Long legalGuideId, Long adminId, String reason, int targetLevelNumber) {
        LegalGuidePerformanceProfile perf = getOrCreatePerformanceProfile(legalGuideId);
        Optional<LegalGuideLevelRule> ruleOpt = levelRuleRepository.findAll().stream()
            .filter(r -> r.getLevelNumber() == targetLevelNumber)
            .findFirst();

        if (ruleOpt.isPresent()) {
            LegalGuideLevelRule rule = ruleOpt.get();
            int oldLevel = perf.getCurrentLevelNumber();
            
            perf.setCurrentLevelNumber(targetLevelNumber);
            perf.setCurrentLevelName(rule.getLevelName());
            perf.setDowngradeReviewRequired(false);
            perf.setLastLevelUpdatedAt(LocalDateTime.now());
            performanceProfileRepository.save(perf);

            // Log negative transaction
            LegalGuideCreditTransaction tx = new LegalGuideCreditTransaction(
                legalGuideId, null, "LEVEL_DOWNGRADED_ADMIN", -25, "Level downgraded by Admin: " + reason, adminId, "ADMIN", "ADMIN"
            );
            creditTransactionRepository.save(tx);

            // Notify privately
            userRepository.findById(legalGuideId).ifPresent(user -> 
                notificationService.create(user, "Level Update: Your performance level has been adjusted to " + rule.getLevelName() + ".", com.aram.legalaid.enums.NotificationType.IN_APP)
            );

            auditLogService.log("LEVEL_DOWNGRADED", "ADMIN_" + adminId, 
                "Guide ID " + legalGuideId + " downgraded from " + oldLevel + " to " + targetLevelNumber + ". Reason: " + reason);
        }
    }

    @Transactional
    public void manualLevelChange(Long legalGuideId, Long adminId, int targetLevelNumber, String reason) {
        LegalGuidePerformanceProfile perf = getOrCreatePerformanceProfile(legalGuideId);
        Optional<LegalGuideLevelRule> ruleOpt = levelRuleRepository.findAll().stream()
            .filter(r -> r.getLevelNumber() == targetLevelNumber)
            .findFirst();

        if (ruleOpt.isPresent()) {
            LegalGuideLevelRule rule = ruleOpt.get();
            int oldLevel = perf.getCurrentLevelNumber();
            
            perf.setCurrentLevelNumber(targetLevelNumber);
            perf.setCurrentLevelName(rule.getLevelName());
            perf.setLastLevelUpdatedAt(LocalDateTime.now());
            performanceProfileRepository.save(perf);

            auditLogService.log("MANUAL_LEVEL_CHANGE", "ADMIN_" + adminId, 
                "Guide ID " + legalGuideId + " manually changed from level " + oldLevel + " to " + targetLevelNumber + ". Reason: " + reason);
        }
    }

    public LegalGuidePerformanceProfile getOrCreatePerformanceProfile(Long legalGuideId) {
        return performanceProfileRepository.findByLegalGuideId(legalGuideId)
            .orElseGet(() -> {
                LegalGuidePerformanceProfile profile = new LegalGuidePerformanceProfile();
                profile.setLegalGuideId(legalGuideId);
                return performanceProfileRepository.save(profile);
            });
    }
}
